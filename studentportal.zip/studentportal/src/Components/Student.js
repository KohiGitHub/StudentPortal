import React, { useState, useEffect } from 'react';
import MarkService from './MarkService'; 
import '../Student.css'; 

const Student = () => {
    const [marksList, setMarksList] = useState([]);

    useEffect(() => {

        MarkService.getAllMarks()
            .then(response => {
                setMarksList(response.data);
            })
            .catch(error => {
                console.error('Error fetching marks:', error);
            });
    }, []); 
    
    const calculatePassFail = mark => {
        return mark >= 225; 
    };

    return (
        <div className="student-marks">
            <h2>Student Marks List</h2>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Subject</th>
                        <th>Mark</th>
                        <th>Pass/Fail</th>
                    </tr>
                </thead>
                <tbody>
                    {marksList.map(mark => (
                        <tr key={mark.mark_id}>
                            <td>{mark.student.name}</td>
                            <td>{mark.subject.subject}</td>
                            <td>{mark.mark}</td>
                            <td>{calculatePassFail(mark.mark) ? "Pass" : "Fail"}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default Student;
