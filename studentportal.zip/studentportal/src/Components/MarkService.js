import axios from "axios";
import React, { Component } from 'react';

const EDUCONNECT_URL = `http://localhost:8080/marks`

class MarkService extends Component {
      

        getAllMarks(){
         
          return axios.get(`${EDUCONNECT_URL}/list`)
         
        }

     saveMark(mark){
        
        return axios.post(`${EDUCONNECT_URL}/save`,mark)

     }
    deleteMark(id){
      
      return axios.delete(`${EDUCONNECT_URL}/delete/`+id)
    }
    getMarkById(id){
     
      return axios.get(`${EDUCONNECT_URL}/get/`+id)
    }
    updateMark(id,mark){
      
      return axios.put(`${EDUCONNECT_URL}/update/`+id,mark)
    }

        
        
    }

export default new  MarkService;
