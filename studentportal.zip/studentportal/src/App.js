import React from 'react';
import './App.css';
import Student from './Components/Student';

function App() {
  return (
    <div className="App">
      <Student/>
    </div>
  );
}

export default App;
