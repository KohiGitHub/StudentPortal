package com.pinnacle.studentportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pinnacle.studentportal.entity.Student;
import com.pinnacle.studentportal.service.StudentService;


@RestController
@RequestMapping("/student")
@CrossOrigin(origins = "http://localhost:3000")
public class StudentController {

	@Autowired
	private StudentService studentservice;

	@PostMapping("/save")
	public Student saveStudent(@RequestBody Student student) {
		return studentservice.saveStudent(student);
	}

	@GetMapping("/list")
	public List<Student> getAllStudents() {

		return studentservice.getAllStudents();
	}

	@GetMapping("/get/{id}")
	public Student getStudentById(@PathVariable long id) {
		return studentservice.getStudentById(id);
	}

	@PutMapping("/update/{id}")
	public Student updateStudent(@PathVariable long id, @RequestBody Student student) {
		return studentservice.updateStudent(id, student);
	}
	
	@DeleteMapping("delete/{id}")
	public Student deleteStudent(@PathVariable long id) {
		return studentservice.deleteStudent(id);
	}


}
