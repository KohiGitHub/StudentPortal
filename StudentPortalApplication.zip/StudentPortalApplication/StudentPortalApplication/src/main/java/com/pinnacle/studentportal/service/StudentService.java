package com.pinnacle.studentportal.service;

import java.util.List;

import com.pinnacle.studentportal.entity.Student;

public interface StudentService {

	public Student saveStudent(Student student);
	public List<Student> getAllStudents();
	public Student getStudentById(long id);
	public Student updateStudent(long id,Student student);
	public Student deleteStudent(long id);
}
