package com.pinnacle.studentportal.service;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;

import com.pinnacle.studentportal.entity.Marks;


public interface MarksService {

	public Marks saveMarks(Marks marks);
	public List<Marks> getAllMarks();
	public Marks getMarksById(long id);
	public Marks updateMarks(long id,Marks marks);
	public Marks deleteMarks(long id);
//	public List<Marks> getMarksByStudentId( long studentId);

}
