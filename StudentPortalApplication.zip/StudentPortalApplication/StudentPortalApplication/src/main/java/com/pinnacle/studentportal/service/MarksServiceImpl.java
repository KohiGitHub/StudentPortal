package com.pinnacle.studentportal.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pinnacle.studentportal.entity.Marks;
import com.pinnacle.studentportal.entity.Subject;
import com.pinnacle.studentportal.repository.MarksRepository;
import com.pinnacle.studentportal.repository.StudentRepository;

@Service
public class MarksServiceImpl implements MarksService {

	@Autowired
	private MarksRepository marksrepository;
	
	@Autowired
	private StudentRepository studentrepository;

	@Override
	public Marks saveMarks(Marks marks) {
		return marksrepository.save(marks);
	}

	@Override
	public List<Marks> getAllMarks() {
		
		return marksrepository.findAll();
	}

	@Override
	public Marks getMarksById(long id) {
		Optional<Marks> optcontainer = marksrepository.findById(id);
		if (optcontainer.isPresent()) {
			return optcontainer.get();
		} else {
			throw new IllegalArgumentException("id not found");
		}

	}

	@Override
	public Marks updateMarks(long id, Marks marks) {
		Optional<Marks> optcontainer = marksrepository.findById(id);
		if (optcontainer.isPresent()) {
			Marks dbmarks = optcontainer.get();
			dbmarks.setMark(marks.getMark());
			return marksrepository.save(dbmarks);
		} else {
			throw new IllegalArgumentException("id not found");
		}
	}

	@Override
	public Marks deleteMarks(long id) {
		Optional<Marks> optcontainer = marksrepository.findById(id);
		if (optcontainer.isPresent()) {
			Marks dbmarks = optcontainer.get();
			marksrepository.deleteById(id);
			return dbmarks;
		} else {
			throw new IllegalArgumentException("id invalid");
		}
	}

/*	@Override
	public  List<Marks> getMarksByStudentId(long studentId) {
		return studentrepository.findById(studentId);
	}*/
	

}
