package com.pinnacle.studentportal.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pinnacle.studentportal.entity.Student;
import com.pinnacle.studentportal.entity.Subject;
import com.pinnacle.studentportal.repository.SubjectRepository;

@Service
public class SubjectServiceImpl implements SubjectService {

	@Autowired
	private SubjectRepository subjectrepository;

	@Override
	public Subject saveSubject(Subject subject) {

		return subjectrepository.save(subject);
	}

	@Override
	public List<Subject> getAllSubjects() {

		return subjectrepository.findAll();
	}

	@Override
	public Subject getSubjectById(long id) {

		Optional<Subject> optcontainer = subjectrepository.findById(id);
		if (optcontainer.isPresent()) {
			return optcontainer.get();
		} else {
			throw new IllegalArgumentException("id not found");
		}

	}

	@Override
	public Subject updateSubject(long id, Subject subject) {
		Optional<Subject> optcontainer = subjectrepository.findById(id);
		if (optcontainer.isPresent()) {
			Subject dbsubject = optcontainer.get();
			dbsubject.setSubject(subject.getSubject());
			return subjectrepository.save(dbsubject);
		} else {
			throw new IllegalArgumentException("id not found");
		}
	}

	@Override
	public Subject deleteSubject(long id) {
		Optional<Subject> optcontainer = subjectrepository.findById(id);
		if (optcontainer.isPresent()) {
			Subject dbsubject = optcontainer.get();
			subjectrepository.deleteById(id);
			return dbsubject;
		} else {
			throw new IllegalArgumentException("id invalid");
		}
	}

}
