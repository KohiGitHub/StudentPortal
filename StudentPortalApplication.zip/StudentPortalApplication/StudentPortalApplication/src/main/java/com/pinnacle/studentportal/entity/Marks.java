package com.pinnacle.studentportal.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "marks")
public class Marks {

	@Id
	@Column(name = "mark_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long markId;

	@ManyToOne
	@JoinColumn(name = "student_id")
	private Student student;

	@ManyToOne
	@JoinColumn(name = "subject_id")
	private Subject subject;

	@Column(name = "mark")
	private int mark;

	public Marks() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Marks(Student student, Subject subject, int mark) {
		super();
		this.student = student;
		this.subject = subject;
		this.mark = mark;
	}

	

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public int getMark() {
		return mark;
	}

	public void setMark(int mark) {
		this.mark = mark;
	}

	public long getMarkId() {
		return markId;
	}

	public void setMarkId(long markId) {
		this.markId = markId;
	}

	@Override
	public String toString() {
		return "Marks [markId=" + markId + ", student=" + student + ", subject=" + subject + ", mark=" + mark + "]";
	}

	

}