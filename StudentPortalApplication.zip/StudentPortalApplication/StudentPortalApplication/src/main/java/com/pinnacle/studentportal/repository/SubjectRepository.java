package com.pinnacle.studentportal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pinnacle.studentportal.entity.Subject;

public interface SubjectRepository  extends  JpaRepository<Subject, Long>{

}
