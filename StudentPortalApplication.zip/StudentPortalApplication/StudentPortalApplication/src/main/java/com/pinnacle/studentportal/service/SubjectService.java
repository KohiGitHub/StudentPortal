package com.pinnacle.studentportal.service;

import java.util.List;

import com.pinnacle.studentportal.entity.Subject;

public interface SubjectService {

	public Subject saveSubject(Subject subject);
	public List<Subject> getAllSubjects();
	public Subject getSubjectById(long id);
	public Subject updateSubject(long id,Subject subject);
	public Subject deleteSubject(long id);
}
