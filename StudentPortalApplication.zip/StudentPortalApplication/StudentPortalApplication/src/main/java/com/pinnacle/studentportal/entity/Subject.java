package com.pinnacle.studentportal.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "subject")
public class Subject {

	@Id
	@Column(name = "subject_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long subjectId;

	@Column(name = "subject")
	private String subject;

	public Subject() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Subject(String subject) {
		super();
		this.subject = subject;
	}

	public long getSubject_id() {
		return subjectId;
	}

	public void setSubject_id(int subject_id) {
		this.subjectId = subject_id;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	@Override
	public String toString() {
		return "Subject [subject_id=" + subjectId + ", subject=" + subject + "]";
	}

}
