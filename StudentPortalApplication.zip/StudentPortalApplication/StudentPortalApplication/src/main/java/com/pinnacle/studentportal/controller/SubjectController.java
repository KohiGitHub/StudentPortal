package com.pinnacle.studentportal.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pinnacle.studentportal.entity.Subject;
import com.pinnacle.studentportal.service.SubjectService;

@RestController
@RequestMapping("/subject")
@CrossOrigin(origins = "http://localhost:3000")
public class SubjectController {

	@Autowired
	private SubjectService subjectservice;
	
	@PostMapping("/save")
	public Subject saveSubject(@RequestBody Subject subject) {
		return subjectservice.saveSubject(subject);
	}
	
	@GetMapping("/list")
	public List<Subject> getAllSubjects() {
		return subjectservice.getAllSubjects();
	}
	
	@GetMapping("/get/{id}")
	public Subject getSubjectById(@PathVariable long id) {
		return subjectservice.getSubjectById(id);
	}

	@PutMapping("/update/{id}")
	public Subject updateSubject(@PathVariable long id,@RequestBody Subject subject) {
		return subjectservice.updateSubject(id, subject);
	}
	
	@DeleteMapping("/delete/{id}")
	public Subject deleteSubject(@PathVariable long id) {
		return subjectservice.deleteSubject(id);
	}




		
}
