package com.pinnacle.studentportal.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "student")
public class Student {

	@Id
	@Column(name = "student_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long studentId;

	@Column(name = "name")
	private String name;

	@Column(name = "pass")
	private boolean pass;

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(String name, boolean pass) {
		super();
		this.name = name;
		this.pass = pass;
	}

	public long getStudent_id() {
		return studentId;
	}

	public void setStudent_id(int student_id) {
		this.studentId = student_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isPass() {
		return pass;
	}

	public void setPass(boolean pass) {
		this.pass = pass;
	}

	@Override
	public String toString() {
		return "Student [student_id=" + studentId + ", name=" + name + ", pass=" + pass + "]";
	}

}
