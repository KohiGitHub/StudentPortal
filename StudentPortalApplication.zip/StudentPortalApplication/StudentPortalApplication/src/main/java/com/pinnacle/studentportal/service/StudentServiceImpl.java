package com.pinnacle.studentportal.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pinnacle.studentportal.entity.Student;
import com.pinnacle.studentportal.repository.StudentRepository;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentrepository;

	@Override
	public Student saveStudent(Student student) {
		return studentrepository.save(student);
	}

	@Override
	public List<Student> getAllStudents() {
		return studentrepository.findAll();
	}

	@Override
	public Student getStudentById(long id) {
		Optional<Student> optcontainer = studentrepository.findById(id);
		if (optcontainer.isPresent()) {
			return optcontainer.get();
		} else {
			throw new IllegalArgumentException("id not found");
		}

	}

	@Override
	public Student updateStudent( long id, Student student) {
		Optional<Student> optcontainer = studentrepository.findById(id);
		if (optcontainer.isPresent()) {
			Student dbstudent = optcontainer.get();

			dbstudent.setName(student.getName());
			dbstudent.setPass(student.isPass());
			return studentrepository.save(dbstudent);

		} else {
			throw new IllegalArgumentException("id not found");
		}
	}

	@Override
	public Student deleteStudent(long id) {
		Optional<Student> optcontainer = studentrepository.findById(id);
		if (optcontainer.isPresent()) {
			Student dbstudent = optcontainer.get();
			studentrepository.deleteById(id);
			return dbstudent;
		} else {
			throw new IllegalArgumentException("id invalid");
		}

	}

}
