package com.pinnacle.studentportal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pinnacle.studentportal.entity.Student;

public interface StudentRepository extends JpaRepository<Student, Long> {

}
