package com.pinnacle.StudentPortalApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
